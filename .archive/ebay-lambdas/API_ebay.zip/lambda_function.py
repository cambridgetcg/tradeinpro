import os
import boto3
import openpyxl
import requests
from io import BytesIO

def lambda_handler(event, context):
    # eBay API credentials and endpoint
    EBAY_AUTH_TOKEN = os.environ.get('EBAY_AUTH_TOKEN', 'YourEbayAuthToken')
    EBAY_REV_ENDPOINT = os.environ.get('EBAY_REV_ENDPOINT', 'https://api.ebay.com/ws/api.dll')
    EBAY_DEV_ID = os.environ.get('EBAY_DEV_ID', 'YourDevId')
    EBAY_APP_ID = os.environ.get('EBAY_APP_ID', 'YourAppId')
    EBAY_CERT_ID = os.environ.get('EBAY_CERT_ID', 'YourCertId')

    # S3 and Excel configuration
    s3_bucket = os.environ.get('S3_BUCKET')
    s3_key1 = os.environ.get('S3_KEY1')
    s3_key2 = os.environ.get('S3_KEY2')
    sheet_name = os.environ.get('SHEET_NAME')
    itemid_column_name = os.environ.get('ITEMID_COLUMN')
    start_price_column_name = os.environ.get('START_PRICE_COLUMN')

    if not all([s3_bucket, s3_key1, s3_key2, sheet_name, itemid_column_name, start_price_column_name]):
        error_msg = ("Missing required environment variables: "
                     "S3_BUCKET, S3_KEY1, S3_KEY2, SHEET_NAME, ITEMID_COLUMN, START_PRICE_COLUMN")
        return {"statusCode": 500, "body": error_msg}

    s3 = boto3.client('s3')
    overall_results = {}
    s3_keys = [s3_key1, s3_key2]

    # Create a requests session to reuse connections.
    session = requests.Session()

    for s3_key in s3_keys:
        print(f"Processing file: {s3_key}")
        try:
            response = s3.get_object(Bucket=s3_bucket, Key=s3_key)
            file_content = response['Body'].read()
        except Exception as e:
            overall_results[s3_key] = {"statusCode": 500, "error": f"Error fetching file {s3_key} from S3: {e}"}
            continue

        try:
            workbook = openpyxl.load_workbook(BytesIO(file_content), data_only=True)
            if sheet_name not in workbook.sheetnames:
                overall_results[s3_key] = {"statusCode": 400, "error": f"Sheet '{sheet_name}' not found in workbook {s3_key}."}
                continue
            sheet = workbook[sheet_name]
        except Exception as e:
            overall_results[s3_key] = {"statusCode": 500, "error": f"Error reading Excel file {s3_key}: {e}"}
            continue

        # Build header mapping for the first row (0-indexed) using a dictionary comprehension.
        header = {cell.value: idx for idx, cell in enumerate(sheet[1]) if cell.value}
        if itemid_column_name not in header or start_price_column_name not in header:
            overall_results[s3_key] = {"statusCode": 400, "error": f"Missing required columns in file {s3_key}."}
            continue

        # Gather rows using a list comprehension.
        rows = [
            (row[header[itemid_column_name]], row[header[start_price_column_name]])
            for row in sheet.iter_rows(min_row=2, values_only=True)
            if row[header[itemid_column_name]] is not None and row[header[start_price_column_name]] is not None
        ]

        batch_size = 4
        file_results = []

        # Process rows in batches.
        for i in range(0, len(rows), batch_size):
            batch = rows[i:i+batch_size]
            # Build the XML payload using string concatenation.
            xml_lines = [
                '<?xml version="1.0" encoding="utf-8"?>',
                '<ReviseInventoryStatusRequest xmlns="urn:ebay:apis:eBLBaseComponents">',
                '<ErrorLanguage>en_US</ErrorLanguage>',
                '<WarningLevel>High</WarningLevel>'
            ]
            for item_id, start_price in batch:
                xml_lines.append(f'<InventoryStatus><ItemID>{item_id}</ItemID><StartPrice>{start_price}</StartPrice></InventoryStatus>')
            xml_lines.append('</ReviseInventoryStatusRequest>')
            xml_payload = "\n".join(xml_lines)

            print(f"Constructed XML Payload for batch starting at row {i+2} in file {s3_key}:")
            print(xml_payload)

            # Make the API call for this batch.
            try:
                api_response = session.post(
                    EBAY_REV_ENDPOINT,
                    data=xml_payload,
                    headers={
                        "Content-Type": "text/xml",
                        "X-EBAY-API-COMPATIBILITY-LEVEL": "967",
                        "X-EBAY-API-DEV-NAME": EBAY_DEV_ID,
                        "X-EBAY-API-APP-NAME": EBAY_APP_ID,
                        "X-EBAY-API-CERT-NAME": EBAY_CERT_ID,
                        "X-EBAY-API-CALL-NAME": "ReviseInventoryStatus",
                        "X-EBAY-API-SITEID": "0",
                        "X-EBAY-API-IAF-TOKEN": EBAY_AUTH_TOKEN
                    }
                )
                api_response.raise_for_status()
                result = {
                    'batch': i // batch_size + 1,
                    'status_code': api_response.status_code,
                    'response_body': api_response.text
                }
            except requests.exceptions.RequestException as e:
                result = {
                    'batch': i // batch_size + 1,
                    'error': str(e)
                }
            file_results.append(result)

        overall_results[s3_key] = {"statusCode": 200, "results": file_results}

    return {"statusCode": 200, "body": overall_results}
