import json
import os
import boto3
import pandas as pd
import requests
import xml.etree.ElementTree as ET
from io import BytesIO

# Initialize S3 client
s3_client = boto3.client('s3')

# Environment variables for S3
PRICE_BUCKET = os.environ.get('PRICE_BUCKET')
PRICE_FILE_KEY = os.environ.get('PRICE_FILE_KEY')
STOCK_BUCKET = os.environ.get('STOCK_BUCKET')
STOCK_FILE_KEY = os.environ.get('STOCK_FILE_KEY')

# Environment variables for sheet names
PRICE_SHEET_NAME = os.environ.get('PRICE_SHEET_NAME')  # Sheet name for price file
STOCK_SHEET_NAME = os.environ.get('STOCK_SHEET_NAME')  # Sheet name for stock file

# eBay Trading API configuration (ReviseInventoryStatus call)
EBAY_REV_ENDPOINT = os.environ.get('EBAY_REV_ENDPOINT')  # e.g., "https://api.ebay.com/ws/api.dll"
EBAY_AUTH_TOKEN = os.environ.get('EBAY_AUTH_TOKEN')      # eBay OAuth token for Trading API
EBAY_DEV_ID = os.environ.get('EBAY_DEV_ID')
EBAY_APP_ID = os.environ.get('EBAY_APP_ID')
EBAY_CERT_ID = os.environ.get('EBAY_CERT_ID')
EBAY_API_COMPATIBILITY_LEVEL = os.environ.get('EBAY_API_COMPATIBILITY_LEVEL') or '967'
EBAY_API_SITE_ID = os.environ.get('EBAY_API_SITE_ID') or '0'

def get_excel_from_s3(bucket, key, sheet_name=None):
    """
    Retrieves an Excel file from S3, reads the specified sheet (if provided),
    normalizes column names to lowercase, and returns a pandas DataFrame.
    """
    response = s3_client.get_object(Bucket=bucket, Key=key)
    content = response['Body'].read()
    df = pd.read_excel(BytesIO(content), sheet_name=sheet_name)
    # Normalize column names to lowercase for case-insensitive matching
    df.columns = df.columns.str.lower()
    return df

def update_ebay_items_batch(items):
    """
    Constructs an XML payload with a batch of items and calls the eBay Trading API (ReviseInventoryStatus).
    
    Args:
        items (list): A list of tuples (item_id, price, quantity, sku)
        
    Returns:
        response: The HTTP response from eBay.
        xml_payload: The XML payload sent.
    """
    # Create root element for ReviseInventoryStatusRequest
    root = ET.Element('ReviseInventoryStatusRequest', xmlns="urn:ebay:apis:eBLBaseComponents")
    error_language = ET.SubElement(root, 'ErrorLanguage')
    error_language.text = 'en_US'
    warning_level = ET.SubElement(root, 'WarningLevel')
    warning_level.text = 'High'
    
    # For each item, add an InventoryStatus element
    for item_id, price, quantity, sku in items:
        inv_status = ET.SubElement(root, 'InventoryStatus')
        
        # Use <ItemID> element per eBay API format
        item_id_elem = ET.SubElement(inv_status, 'ItemID')
        try:
            item_id_int = int(item_id)
        except Exception:
            item_id_int = item_id
        item_id_elem.text = str(item_id_int)
        
        # Include the SKU element if a SKU is provided
        if sku:
            sku_elem = ET.SubElement(inv_status, 'SKU')
            sku_elem.text = str(sku)
        
        start_price_elem = ET.SubElement(inv_status, 'StartPrice')
        start_price_elem.text = str(price)
        
        quantity_elem = ET.SubElement(inv_status, 'Quantity')
        quantity_elem.text = str(quantity)
    
    # Convert XML tree to a string with XML declaration
    xml_str = ET.tostring(root, encoding='utf-8', method='xml')
    xml_declaration = b'<?xml version="1.0" encoding="utf-8"?>\n'
    final_xml = xml_declaration + xml_str
    xml_payload = final_xml.decode('utf-8')
    
    # Define headers for the Trading API call
    headers = {
        "Content-Type": "text/xml",
        "X-EBAY-API-COMPATIBILITY-LEVEL": EBAY_API_COMPATIBILITY_LEVEL,
        "X-EBAY-API-DEV-NAME": EBAY_DEV_ID,
        "X-EBAY-API-APP-NAME": EBAY_APP_ID,
        "X-EBAY-API-CERT-NAME": EBAY_CERT_ID,
        "X-EBAY-API-CALL-NAME": "ReviseInventoryStatus",
        "X-EBAY-API-SITEID": EBAY_API_SITE_ID,
        "X-EBAY-API-IAF-TOKEN": EBAY_AUTH_TOKEN
    }
    
    # Send the API request
    response = requests.post(EBAY_REV_ENDPOINT, data=xml_payload, headers=headers)
    return response, xml_payload

def lambda_handler(event, context):
    try:
        # Retrieve Excel data from S3 using the specified sheet names.
        price_df = get_excel_from_s3(PRICE_BUCKET, PRICE_FILE_KEY, sheet_name=PRICE_SHEET_NAME)
        stock_df = get_excel_from_s3(STOCK_BUCKET, STOCK_FILE_KEY, sheet_name=STOCK_SHEET_NAME)
        
        # Ensure required columns exist in each DataFrame.
        # For the price file: "ebay_item_number", "selling_price", and "sku"
        required_price_cols = {"ebay_item_number", "selling_price", "sku"}
        missing_price_cols = required_price_cols - set(price_df.columns)
        if missing_price_cols:
            raise ValueError(f"Missing column(s) in price file: {missing_price_cols}")
        
        # For the stock file: "ebay_item_number" and "quantity"
        required_stock_cols = {"ebay_item_number", "quantity"}
        missing_stock_cols = required_stock_cols - set(stock_df.columns)
        if missing_stock_cols:
            raise ValueError(f"Missing column(s) in stock file: {missing_stock_cols}")
        
        # Build dictionaries for fast lookup.
        price_dict = dict(zip(price_df['ebay_item_number'], price_df['selling_price']))
        sku_dict = dict(zip(price_df['ebay_item_number'], price_df['sku']))
        stock_dict = dict(zip(stock_df['ebay_item_number'], stock_df['quantity']))
        
        # Prepare list of items that have both price and quantity available.
        items_to_update = []
        common_items = set(price_dict.keys()).intersection(stock_dict.keys())
        for item in common_items:
            sku = sku_dict.get(item, None)
            items_to_update.append((item, price_dict[item], stock_dict[item], sku))
        
        # Batch items (using a batch size of 4)
        batch_size = 4
        results = []
        for i in range(0, len(items_to_update), batch_size):
            batch = items_to_update[i:i+batch_size]
            response, xml_payload = update_ebay_items_batch(batch)
            result = {
                "batch": i // batch_size + 1,
                "status_code": response.status_code,
                "response": response.text,
                "xml_payload": xml_payload
            }
            results.append(result)
        
        return {
            'statusCode': 200,
            'body': json.dumps(results)
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
