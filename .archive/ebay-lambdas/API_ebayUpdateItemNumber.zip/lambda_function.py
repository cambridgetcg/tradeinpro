import os
import boto3
from openpyxl import load_workbook
from io import BytesIO

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Retrieve environment variables for buckets and file keys
    primary_bucket = os.environ.get('PRIMARY_BUCKET_NAME')
    lookup_bucket = os.environ.get('LOOKUP_BUCKET_NAME')
    primary_file_keys_str = os.environ.get('PRIMARY_FILE_KEY')  # Comma-separated list of keys
    lookup_file_key = os.environ.get('LOOKUP_FILE_KEY')
    primary_sheet_name = os.environ.get('PRIMARY_SHEET_NAME')   # Targeted sheet name in primary files
    
    if not primary_bucket or not lookup_bucket or not primary_file_keys_str or not lookup_file_key or not primary_sheet_name:
        return {
            'statusCode': 500,
            'body': ('Environment variables PRIMARY_BUCKET_NAME, LOOKUP_BUCKET_NAME, '
                     'PRIMARY_FILE_KEY, LOOKUP_FILE_KEY, and PRIMARY_SHEET_NAME must be set.')
        }
    
    # Convert comma separated list into a list of keys
    primary_file_keys = [key.strip() for key in primary_file_keys_str.split(',') if key.strip()]
    
    try:
        # Download lookup Excel file from S3 (lookup bucket)
        lookup_obj = s3.get_object(Bucket=lookup_bucket, Key=lookup_file_key)
        lookup_data = lookup_obj['Body'].read()
        lookup_wb = load_workbook(filename=BytesIO(lookup_data))
        lookup_ws = lookup_wb.active
        
        # Build header mapping for the lookup sheet (case-insensitive)
        lookup_headers = {}
        for col in range(1, lookup_ws.max_column + 1):
            cell_value = lookup_ws.cell(row=1, column=col).value
            if cell_value:
                lookup_headers[str(cell_value).strip().lower()] = col
        
        # Ensure the lookup file contains both required columns (case-insensitive)
        if 'custom label (sku)' not in lookup_headers or 'item number' not in lookup_headers:
            raise Exception("Lookup file must contain both 'Custom label (SKU)' and 'Item number' columns.")
        
        # Create a dictionary mapping SKU (in lower-case) to its corresponding Item number
        lookup_dict = {}
        sku_col_lookup = lookup_headers['custom label (sku)']
        item_number_col = lookup_headers['item number']
        for row in range(2, lookup_ws.max_row + 1):
            sku_val = lookup_ws.cell(row=row, column=sku_col_lookup).value
            item_number_val = lookup_ws.cell(row=row, column=item_number_col).value
            if sku_val is not None:
                lookup_dict[str(sku_val).strip().lower()] = item_number_val
        
        # Process each primary file from the list
        for primary_file_key in primary_file_keys:
            # Download primary Excel file from S3 (primary bucket)
            primary_obj = s3.get_object(Bucket=primary_bucket, Key=primary_file_key)
            primary_data = primary_obj['Body'].read()
            primary_wb = load_workbook(filename=BytesIO(primary_data))
            
            # Get the targeted sheet by name
            if primary_sheet_name not in primary_wb.sheetnames:
                raise Exception(f"Sheet '{primary_sheet_name}' not found in file {primary_file_key}.")
            primary_ws = primary_wb[primary_sheet_name]
            
            # Build header mapping for the targeted primary sheet (case-insensitive)
            primary_headers = {}
            for col in range(1, primary_ws.max_column + 1):
                cell_value = primary_ws.cell(row=1, column=col).value
                if cell_value:
                    primary_headers[str(cell_value).strip().lower()] = col
            
            # Ensure the primary file contains the 'sku' column (case-insensitive)
            if 'sku' not in primary_headers:
                raise Exception(f"Primary file {primary_file_key} does not contain a 'SKU' column in sheet {primary_sheet_name}.")
            
            # Check if the 'ebay_item_number' column exists; if not, add it as the next column
            if 'ebay_item_number' not in primary_headers:
                new_col = primary_ws.max_column + 1
                primary_ws.cell(row=1, column=new_col, value='ebay_item_number')
                primary_headers['ebay_item_number'] = new_col
            
            # Get column indexes for 'sku' and 'ebay_item_number'
            sku_col_primary = primary_headers['sku']
            ebay_item_number_col = primary_headers['ebay_item_number']
            
            # Update rows in the primary sheet based on the lookup dictionary
            for row in range(2, primary_ws.max_row + 1):
                sku_val = primary_ws.cell(row=row, column=sku_col_primary).value
                if sku_val is not None:
                    sku_val_lower = str(sku_val).strip().lower()
                    if sku_val_lower in lookup_dict:
                        primary_ws.cell(row=row, column=ebay_item_number_col, value=lookup_dict[sku_val_lower])
            
            # Save the updated workbook to an in-memory bytes buffer
            out_buffer = BytesIO()
            primary_wb.save(out_buffer)
            out_buffer.seek(0)
            
            # Upload the updated primary file back to S3 (overwrite original)
            s3.put_object(Bucket=primary_bucket, Key=primary_file_key, Body=out_buffer.getvalue())
        
        return {
            'statusCode': 200,
            'body': 'Primary Excel file(s) updated successfully.'
        }
    
    except Exception as e:
        print(f"Error processing files: {e}")
        return {
            'statusCode': 500,
            'body': f"Error processing files: {e}"
        }
